module Main where

import Simple

main :: IO ()
main = do
    let solved_database = solve []
    print (facts solved_database)
