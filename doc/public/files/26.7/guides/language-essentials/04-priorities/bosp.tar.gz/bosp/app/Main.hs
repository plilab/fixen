module Main where

import BOSP

main :: IO ()
main = do
    let facts =
            [ DistTo "A" 0 0 -- our starting vertex
            , Edge "A" "B" 5 1
            , Edge "A" "B" 1 5
            , Edge "B" "C" 3 1
            , Edge "C" "D" 1 3
            ]
        db = solve facts
    -- db now contains the shortest distances from "A" to all reachable vertices
    print (distances db)
