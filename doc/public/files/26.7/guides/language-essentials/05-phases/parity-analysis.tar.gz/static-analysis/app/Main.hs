module Main where

import Common
import Numeric.Natural
import ParityAnalysis

main :: IO ()
main = do
    let facts =
            [ Var 0 "v"
            , Seq 0 1
            , Assign 1 "v" (Num 1)
            , Seq 1 2
            , Branch 2 (Leq "v" (Num 9)) 3 5
            , Assign 3 "v" (Plus (Id "v") (Num 2))
            , Seq 3 2
            , Branch 5 (Eq "v" (Num 11)) 6 101
            , Assign 6 "v" (Num 0)
            , Seq 6 101
            , Var 101 "END"
            ]
        db = solve facts
    (label :: Natural) <- readLn
    print (stateBeforeP label db)
