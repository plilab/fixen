module Main where

import Reachability

main :: IO ()
main = do
    let edges =
            [ Edge "Paris" "Tokyo"
            , Edge "Tokyo" "New York"
            ]
    let solved_database = solve edges
    print (allPaths solved_database)
