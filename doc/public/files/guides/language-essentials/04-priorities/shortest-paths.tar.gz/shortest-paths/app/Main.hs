module Main where

import ShortestPath

main :: IO ()
main = do
    let facts =
            [ DistTo "A" 0 -- our starting vertex
            , Edge "A" "B" 1
            , Edge "B" "C" 2
            , Edge "C" "A" 10
            , Edge "C" "D" 1
            ]
        db = solve facts
    -- db now contains the shortest distances from "A" to all reachable vertices
    print (distances db)
