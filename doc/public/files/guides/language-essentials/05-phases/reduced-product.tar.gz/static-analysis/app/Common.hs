module Common where

import Algebra.PartialOrd
import Data.Hashable
import GHC.Generics
import Numeric.Natural

data Expr
    = Id String -- x
    | Num Int -- 1
    | Plus Expr Expr -- e + e'
    | Leq String Expr -- x <= e
    | Eq String Expr -- x = e
    deriving (Eq, Generic, Show)

instance Hashable Expr

type Label = Natural

data BBool = BTop | BBot | BTrue | BFalse
    deriving (Eq, Generic, Show)

instance PartialOrd BBool where
    BBot `leq` _ = True
    _ `leq` BTop = True
    x `leq` y = x == y
