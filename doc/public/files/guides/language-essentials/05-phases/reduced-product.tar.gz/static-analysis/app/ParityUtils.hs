{-# LANGUAGE OverlappingInstances #-}

module ParityUtils where

import Algebra.Lattice
import Algebra.PartialOrd
import Common
import Data.HashMap.Strict (HashMap)
import Data.HashMap.Strict qualified as HashMap
import Data.List (intercalate)

data Parity = PBot | Even | Odd | PTop
    deriving (Eq, Show)

instance Show (HashMap String Parity) where
    show m = "{ " ++ intercalate ", " (fmap (\(k, v) -> k ++ ": " ++ show v) (HashMap.toList m)) ++ " }"

instance PartialOrd Parity where
    leq PBot _ = True
    leq _ PTop = True
    leq PTop _ = False
    leq _ PBot = False
    x `leq` y = x == y

instance Lattice Parity where
    PTop \/ _ = PTop
    _ \/ PTop = PTop
    PBot \/ x = x
    x \/ PBot = x
    x \/ y
        | x == y = x
        | otherwise = PTop

    PBot /\ _ = PBot
    _ /\ PBot = PBot
    PTop /\ x = x
    x /\ PTop = x
    x /\ y
        | x == y = x
        | otherwise = PBot

-- Easy lookups for parities in state
lookupParity :: String -> HashMap String Parity -> Parity
lookupParity = HashMap.lookupDefault PBot

-- Evaluates an expression, giving a parity.
evalP :: Expr -> HashMap String Parity -> Parity
evalP (Id x) st = lookupParity x st
evalP (Num i) _ = if even i then Even else Odd
evalP (Plus e e') st = case (evalP e st, evalP e' st) of
    (Even, Odd) -> Odd
    (Odd, Even) -> Odd
    (Odd, Odd) -> Even
    (Even, Even) -> Even
    (PBot, _) -> PBot
    (_, PBot) -> PBot
    _ -> PTop
evalP _ _ = PBot

-- Evaluates a condition, giving a BBool.
evalCondP :: Expr -> HashMap String Parity -> BBool
evalCondP (Eq x e) st = case (lookupParity x st, evalP e st) of
    (Even, Odd) -> BFalse
    (Odd, Even) -> BFalse
    (PBot, _) -> BBot
    (_, PBot) -> BBot
    _ -> BTop
evalCondP (Leq _ _) _ = BTop
evalCondP _ _ = BBot

-- Refines parities assuming a condition is true.
refineTP :: Expr -> HashMap String Parity -> HashMap String Parity
refineTP (Eq x e) st =
    let p = evalP e st
     in HashMap.insert x (lookupParity x st /\ p) st
refineTP _ st = st

-- Refines parities assuming a condition is false.
refineFP :: Expr -> HashMap String Parity -> HashMap String Parity
refineFP (Eq x e) st =
    let p = if evalP e st == Even then Odd else Even
     in HashMap.insert x (lookupParity x st /\ p) st
refineFP _ st = st
