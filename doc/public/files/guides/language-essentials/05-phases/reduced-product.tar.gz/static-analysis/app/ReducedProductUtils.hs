module ReducedProductUtils where

import Data.HashMap.Strict (HashMap)
import Data.HashMap.Strict qualified as HashMap
import IntervalUtils
import ParityUtils

reducedExchangeI ::
    HashMap String Parity ->
    HashMap String Interval ->
    HashMap String Interval
reducedExchangeI st st' = HashMap.fromList $ do
    (v, int) <- HashMap.toList st'
    return $ case int of
        Pair a b -> case lookupParity v st of
            Odd ->
                let a' = if even a then a + 1 else a
                    b' = if even b then b - 1 else b
                 in (v, a' ... b')
            Even ->
                let a' = if odd a then a + 1 else a
                    b' = if odd b then b - 1 else b
                 in (v, a' ... b')
            PBot -> (v, IBot)
            _ -> (v, int)
        _ -> (v, int)
