{-# LANGUAGE MultiWayIf #-}
{-# LANGUAGE OverlappingInstances #-}

module IntervalUtils where

import Algebra.Lattice
import Algebra.PartialOrd
import Common
import Data.HashMap.Strict (HashMap)
import Data.HashMap.Strict qualified as HashMap
import Data.List (intercalate)

data Interval = Pair Int Int | ITop | IBot
    deriving (Eq)

instance Show Interval where
    show (Pair a b) = "[" ++ show a ++ ", " ++ show b ++ "]"
    show ITop = "[-inf, inf]"
    show IBot = "empty"

instance Show (HashMap String Interval) where
    show m = "{ " ++ intercalate ", " (fmap (\(k, v) -> k ++ ": " ++ show v) (HashMap.toList m)) ++ " }"

(...) :: Int -> Int -> Interval
a ... b = if a > b then IBot else Pair a b

infix 5 ...

instance PartialOrd Interval where
    leq IBot _ = True
    leq _ ITop = True
    leq ITop _ = False
    leq _ IBot = False
    Pair a b `leq` Pair c d = a >= c && b <= d

instance Lattice Interval where
    ITop \/ _ = ITop
    _ \/ ITop = ITop
    IBot \/ x = x
    x \/ IBot = x
    Pair a b \/ Pair c d = min a c ... max b d

    IBot /\ _ = IBot
    _ /\ IBot = IBot
    ITop /\ x = x
    x /\ ITop = x
    Pair a b /\ Pair c d = max a c ... min b d

-- Easy lookups for intervals in state
lookupInterval :: String -> HashMap String Interval -> Interval
lookupInterval = HashMap.lookupDefault IBot

-- Puts a cap on the upper bound of an interval.
withUpperBound :: Int -> Interval -> Interval
withUpperBound n (Pair a b) = if n < b then a ... n else a ... b
withUpperBound _ x = x

-- Puts a minimum on the lower bound of an interval.
withLowerBound :: Int -> Interval -> Interval
withLowerBound n (Pair a b) = if n > a then n ... b else a ... b
withLowerBound _ x = x

-- Evaluates an expression, giving an interval.
evalI :: Expr -> HashMap String Interval -> Interval
evalI (Id x) st = lookupInterval x st
evalI (Num i) _ = i ... i
evalI (Plus e e') st = case (evalI e st, evalI e' st) of
    (Pair a b, Pair c d) -> a + c ... b + d
    (IBot, _) -> IBot
    (_, IBot) -> IBot
    _ -> ITop
evalI _ _ = IBot

-- Evaluates a condition, giving a BBool.
evalCondI :: Expr -> HashMap String Interval -> BBool
evalCondI (Leq x e) st = case (lookupInterval x st, evalI e st) of
    (Pair a b, Pair c d) ->
        if
            | b <= c -> BTrue
            | a > d -> BFalse
            | otherwise -> BTop
    (IBot, _) -> BBot
    (_, IBot) -> BBot
    _ -> BTop
evalCondI (Eq x e) st = case (lookupInterval x st, evalI e st) of
    (Pair a b, Pair c d) ->
        if
            | a == b && a == c && b == d -> BTrue
            | b < c || a > d -> BFalse
            | otherwise -> BTop
    (IBot, _) -> BBot
    (_, IBot) -> BBot
    _ -> BTop
evalCondI _ _ = BBot

-- Refines intervals assuming a condition is true.
refineTI :: Expr -> HashMap String Interval -> HashMap String Interval
refineTI (Leq x e) st = case evalI e st of
    Pair _ b ->
        let int = withUpperBound b $ lookupInterval x st
         in HashMap.insert x int st
    _ -> st
refineTI (Eq x e) st =
    let int = lookupInterval x st /\ evalI e st
     in HashMap.insert x int st
refineTI _ st = st

-- Refines intervals assuming a condition is true.
refineFI :: Expr -> HashMap String Interval -> HashMap String Interval
refineFI (Leq x e) st = case evalI e st of
    Pair a _ ->
        let int = withLowerBound (a + 1) $ lookupInterval x st
         in HashMap.insert x int st
    _ -> st
refineFI (Eq x e) st = case (lookupInterval x st, evalI e st) of
    (Pair a b, Pair c d) ->
        if c == d
            then
                if
                    | b == c -> HashMap.insert x (a ... b - 1) st
                    | a == c -> HashMap.insert x (a + 1 ... b) st
                    | otherwise -> st
            else
                st
    _ -> st
refineFI _ st = st
